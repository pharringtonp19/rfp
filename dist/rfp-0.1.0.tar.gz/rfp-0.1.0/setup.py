# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rfp', 'rfp._src', 'rfp._src.kernels']

package_data = \
{'': ['*']}

install_requires = \
['diffrax>=0.2.1,<0.3.0',
 'distrax>=0.1.2,<0.2.0',
 'einops>=0.4.1,<0.5.0',
 'flax>=0.5.3,<0.6.0',
 'isort>=5.10.1,<6.0.0',
 'jax>=0.4.1,<0.5.0',
 'jaxlib>=0.4.1,<0.5.0',
 'jaxopt>=0.5.5,<0.6.0',
 'mkdocs-material>=8.4.1,<9.0.0',
 'mkdocstrings[python]>=0.19.0,<0.20.0',
 'statsmodels>=0.13.5,<0.14.0',
 'tinygp>=0.2.3,<0.3.0',
 'tree-math>=0.1.0,<0.2.0']

setup_kwargs = {
    'name': 'rfp',
    'version': '0.1.0',
    'description': '"Regularizing the Forward Pass"',
    'long_description': 'None',
    'author': 'Patrick Power',
    'author_email': 'pharringtonp19@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://pharringtonp19.github.io/rfp/',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0.0',
}


setup(**setup_kwargs)
