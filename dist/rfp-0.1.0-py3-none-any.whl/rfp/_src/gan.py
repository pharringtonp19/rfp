def f(x):
    return x 