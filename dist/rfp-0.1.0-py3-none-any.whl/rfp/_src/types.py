from typing import Any, TypeAlias

import jax

Params: TypeAlias = Any
Array: TypeAlias = Any
