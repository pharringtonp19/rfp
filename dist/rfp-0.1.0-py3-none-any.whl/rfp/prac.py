def double(n: int):
    return n * 2


num = double(21)
print(num)
